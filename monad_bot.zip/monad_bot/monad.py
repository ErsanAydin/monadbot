import os
import time
import random
from web3 import Web3
from dotenv import load_dotenv
from colorama import Fore, Style

# .env dosyasından ortam değişkenlerini yükle
load_dotenv()

# RPC ve Cüzdan Ayarları
RPC_URL = os.getenv("RPC_URL", "https://testnet-rpc.monorail.xyz")  # .env'den RPC_URL al, yoksa varsayılanı kullan
PRIVATE_KEY = os.getenv("PRIVATE_KEY")
WALLET_ADDRESS = os.getenv("WALLET_ADDRESS")

# Zincir Kimliği (Chain ID) - Monad Testnet için
CHAIN_ID = 10143  # Monad test ağı zincir kimliği

# Web3 bağlantısı
web3 = Web3(Web3.HTTPProvider(RPC_URL))
if not web3.is_connected():
    raise Exception("RPC bağlantısı başarısız.")

# Token ve Kontrat Adresleri
WMON_CONTRACT_ADDRESS = web3.to_checksum_address("0x760AfE86e5de5fa0Ee542fc7B7B713e1c5425701")
UNISWAP_V2_ROUTER_ADDRESS = web3.to_checksum_address("0xCa810D095e90Daae6e867c19DF6D9A8C56db2c89")
WETH_ADDRESS = web3.to_checksum_address("0x760AfE86e5de5fa0Ee542fc7B7B713e1c5425701")

# aPriori ve Kitsu Kontrat Adresleri
APRIORI_CONTRACT_ADDRESS = web3.to_checksum_address("0xb2f82D0f38dc453D596Ad40A37799446Cc89274A")
KITSU_CONTRACT_ADDRESS = web3.to_checksum_address("0x2c9C959516e9AAEdB2C748224a41249202ca8BE7")

# Bean, Bebop ve Mono DEX Kontrat Adresleri
BEAN_ROUTER_ADDRESS = web3.to_checksum_address("0x1234567890123456789012345678901234567890")  # Bean Router Adresi (Örnek adres, gerçek adresi girin)
BEBOP_CONTRACT_ADDRESS = web3.to_checksum_address("0x1234567890123456789012345678901234567890")  # Bebop Kontrat Adresi (Örnek adres, gerçek adresi girin)
MONO_CONTRACT_ADDRESS = web3.to_checksum_address("0x1234567890123456789012345678901234567890")  # Mono Kontrat Adresi (Örnek adres, gerçek adresi girin)

# Token Adresleri
TOKEN_ADDRESSES = {
    "DAC": web3.to_checksum_address("0x0f0bdebf0f83cd1ee3974779bcb7315f9808c714"),
    "USDT": web3.to_checksum_address("0x88b8e2161dedc77ef4ab7585569d2415a1c1055d"),
    "WETH": web3.to_checksum_address("0x836047a99e11f376522b447bffb6e3495dd0637c"),
    "MUK": web3.to_checksum_address("0x989d38aeed8408452f0273c7d4a17fef20878e62"),
    "USDC": web3.to_checksum_address("0xf817257fed379853cDe0fa4F97AB987181B1E5Ea"),
    "CHOG": web3.to_checksum_address("0xE0590015A873bF326bd645c3E1266d4db41C4E6B")
}

# Sabit bekleme süresi (5 saniye)
FIXED_DELAY = 5  # 5 saniye

# Rastgele Miktar Fonksiyonu
def get_random_amount(min, max):
    return web3.to_wei(random.uniform(min, max), 'ether')

# Rastgele Bekleme Süresi (Kullanıcıdan alınan min ve max değerlerine göre)
def get_random_delay(min_delay, max_delay):
    delay_seconds = random.randint(min_delay, max_delay)  # Kullanıcıdan alınan min ve max değerlerine göre rastgele süre (saniye cinsinden)
    print(f"{Fore.YELLOW}⏳ {delay_seconds // 60} dakika {delay_seconds % 60} saniye bekleniyor...{Style.RESET_ALL}")
    return delay_seconds

# Cüzdan Bakiyesini Kontrol Etme
def check_balance(min_balance_eth):
    balance = web3.eth.get_balance(WALLET_ADDRESS)
    balance_eth = web3.from_wei(balance, 'ether')
    if balance_eth < min_balance_eth:
        print(f"{Fore.RED}❌ Yetersiz bakiye: {balance_eth} ETH (Minimum gereken: {min_balance_eth} ETH){Style.RESET_ALL}")
        return False
    return True

# Gas Ücretlerini Otomatik Tahmin Etme
def get_dynamic_gas_fees():
    try:
        # Son blokların gas ücretlerini al
        fee_history = web3.eth.fee_history(1, 'latest', [10, 90])
        base_fee = fee_history['baseFeePerGas'][-1]
        max_priority_fee = web3.to_wei(2, 'gwei')  # Öncelik ücreti (2 Gwei)
        max_fee_per_gas = base_fee + max_priority_fee  # Maksimum gas ücreti

        return {
            'maxFeePerGas': max_fee_per_gas,
            'maxPriorityFeePerGas': max_priority_fee
        }
    except Exception as e:
        print(f"{Fore.RED}❌ Gas ücretleri tahmin edilirken hata: {e}{Style.RESET_ALL}")
        return {
            'maxFeePerGas': web3.to_wei(20, 'gwei'),  # Varsayılan değer
            'maxPriorityFeePerGas': web3.to_wei(2, 'gwei')  # Varsayılan değer
        }

# aPriori Stake İşlemi
def stake_apriori_mon(amount):
    try:
        print(f"{Fore.CYAN}🔄 {web3.from_wei(amount, 'ether')} MON > aPriori Stake yapılıyor...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        # Stake işlemi için data hazırlama
        data = "0x6e553f65" + amount.to_bytes(32, byteorder='big').hex() + WALLET_ADDRESS[2:].zfill(64)

        tx = {
            'to': APRIORI_CONTRACT_ADDRESS,
            'data': data,
            'gas': 500000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'value': amount,
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        }

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ aPriori Stake başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
        web3.eth.wait_for_transaction_receipt(tx_hash)
    except Exception as e:
        print(f"{Fore.RED}❌ aPriori Stake hatası: {e}{Style.RESET_ALL}")

# aPriori Unstake İşlemi
def unstake_apriori_mon(amount):
    try:
        print(f"{Fore.CYAN}🔄 {web3.from_wei(amount, 'ether')} aprMON > MON çevriliyor...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        # Unstake işlemi için data hazırlama
        data = "0x7d41c86e" + amount.to_bytes(32, byteorder='big').hex() + WALLET_ADDRESS[2:].zfill(64) + WALLET_ADDRESS[2:].zfill(64)

        tx = {
            'to': APRIORI_CONTRACT_ADDRESS,
            'data': data,
            'gas': 800000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'value': 0,
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        }

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ aPriori Unstake başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
        web3.eth.wait_for_transaction_receipt(tx_hash)
    except Exception as e:
        print(f"{Fore.RED}❌ aPriori Unstake hatası: {e}{Style.RESET_ALL}")

# Kitsu Stake İşlemi
def stake_kitsu_mon(amount):
    try:
        print(f"{Fore.CYAN}🔄 {web3.from_wei(amount, 'ether')} MON > Kitsu Stake yapılıyor...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        # Stake işlemi için data hazırlama
        data = "0xd5575982"

        tx = {
            'to': KITSU_CONTRACT_ADDRESS,
            'data': data,
            'gas': 500000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'value': amount,
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        }

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Kitsu Stake başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
        web3.eth.wait_for_transaction_receipt(tx_hash)
    except Exception as e:
        print(f"{Fore.RED}❌ Kitsu Stake hatası: {e}{Style.RESET_ALL}")

# Kitsu Unstake İşlemi
def unstake_kitsu_mon(amount):
    try:
        print(f"{Fore.CYAN}🔄 {web3.from_wei(amount, 'ether')} gMON > MON çevriliyor...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        # Unstake işlemi için data hazırlama
        data = "0x6fed1ea7" + amount.to_bytes(32, byteorder='big').hex()

        tx = {
            'to': KITSU_CONTRACT_ADDRESS,
            'data': data,
            'gas': 800000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'value': 0,
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        }

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Kitsu Unstake başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
        web3.eth.wait_for_transaction_receipt(tx_hash)
    except Exception as e:
        print(f"{Fore.RED}❌ Kitsu Unstake hatası: {e}{Style.RESET_ALL}")

# Uniswap Swap İşlemleri
def swap_eth_for_tokens(token_address, token_symbol):
    router = web3.eth.contract(address=UNISWAP_V2_ROUTER_ADDRESS, abi=[
        {
            "name": "swapExactETHForTokens",
            "type": "function",
            "stateMutability": "payable",
            "inputs": [
                {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
                {"internalType": "address[]", "name": "path", "type": "address[]"},
                {"internalType": "address", "name": "to", "type": "address"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"}
            ],
            "outputs": []
        }
    ])

    amount_in_wei = get_random_amount(0.001, 0.01)

    try:
        print(f"{Fore.YELLOW}🔄 {web3.from_wei(amount_in_wei, 'ether')} MON > {token_symbol} takası yapılıyor (DEX: Uniswap V2)...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        tx = router.functions.swapExactETHForTokens(
            0,
            [WETH_ADDRESS, token_address],
            WALLET_ADDRESS,
            int(time.time()) + 60 * 10
        ).build_transaction({
            'value': amount_in_wei,
            'gas': 200000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        })

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Takas başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Takas hatası: {e}{Style.RESET_ALL}")

# Bean DEX İşlemleri
def bean_swap_eth_for_tokens(token_address, token_symbol):
    router = web3.eth.contract(address=BEAN_ROUTER_ADDRESS, abi=[
        {
            "name": "swapExactETHForTokens",
            "type": "function",
            "stateMutability": "payable",
            "inputs": [
                {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
                {"internalType": "address[]", "name": "path", "type": "address[]"},
                {"internalType": "address", "name": "to", "type": "address"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"}
            ],
            "outputs": []
        }
    ])

    amount_in_wei = get_random_amount(0.001, 0.01)

    try:
        print(f"{Fore.YELLOW}🔄 {web3.from_wei(amount_in_wei, 'ether')} MON > {token_symbol} takası yapılıyor (DEX: Bean)...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        tx = router.functions.swapExactETHForTokens(
            0,
            [WETH_ADDRESS, token_address],
            WALLET_ADDRESS,
            int(time.time()) + 60 * 10
        ).build_transaction({
            'value': amount_in_wei,
            'gas': 200000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        })

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Bean Takas başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Bean Takas hatası: {e}{Style.RESET_ALL}")

# Bebop DEX İşlemleri
def bebop_swap_eth_for_tokens(token_address, token_symbol):
    router = web3.eth.contract(address=BEBOP_CONTRACT_ADDRESS, abi=[
        {
            "name": "swapExactETHForTokens",
            "type": "function",
            "stateMutability": "payable",
            "inputs": [
                {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
                {"internalType": "address[]", "name": "path", "type": "address[]"},
                {"internalType": "address", "name": "to", "type": "address"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"}
            ],
            "outputs": []
        }
    ])

    amount_in_wei = get_random_amount(0.001, 0.01)

    try:
        print(f"{Fore.YELLOW}🔄 {web3.from_wei(amount_in_wei, 'ether')} MON > {token_symbol} takası yapılıyor (DEX: Bebop)...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        tx = router.functions.swapExactETHForTokens(
            0,
            [WETH_ADDRESS, token_address],
            WALLET_ADDRESS,
            int(time.time()) + 60 * 10
        ).build_transaction({
            'value': amount_in_wei,
            'gas': 200000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        })

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Bebop Takas başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Bebop Takas hatası: {e}{Style.RESET_ALL}")

# Mono DEX İşlemleri
def mono_swap_eth_for_tokens(token_address, token_symbol):
    router = web3.eth.contract(address=MONO_CONTRACT_ADDRESS, abi=[
        {
            "name": "swapExactETHForTokens",
            "type": "function",
            "stateMutability": "payable",
            "inputs": [
                {"internalType": "uint256", "name": "amountOutMin", "type": "uint256"},
                {"internalType": "address[]", "name": "path", "type": "address[]"},
                {"internalType": "address", "name": "to", "type": "address"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"}
            ],
            "outputs": []
        }
    ])

    amount_in_wei = get_random_amount(0.001, 0.01)

    try:
        print(f"{Fore.YELLOW}🔄 {web3.from_wei(amount_in_wei, 'ether')} MON > {token_symbol} takası yapılıyor (DEX: Mono)...{Style.RESET_ALL}")
        
        # Gas ücretlerini dinamik olarak al
        gas_fees = get_dynamic_gas_fees()

        tx = router.functions.swapExactETHForTokens(
            0,
            [WETH_ADDRESS, token_address],
            WALLET_ADDRESS,
            int(time.time()) + 60 * 10
        ).build_transaction({
            'value': amount_in_wei,
            'gas': 200000,
            'maxFeePerGas': gas_fees['maxFeePerGas'],
            'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
            'nonce': web3.eth.get_transaction_count(WALLET_ADDRESS),
            'chainId': CHAIN_ID  # Zincir kimliği eklendi
        })

        signed_tx = web3.eth.account.sign_transaction(tx, PRIVATE_KEY)
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)
        print(f"{Fore.GREEN}✅ Mono Takas başarılı | Hash: {web3.to_hex(tx_hash)}{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Mono Takas hatası: {e}{Style.RESET_ALL}")

# Ana İşlem Döngüsü
def main():
    print(f"{Fore.GREEN}Monad Testnet Botu başlatılıyor...{Style.RESET_ALL}")

    # Kullanıcıdan bekleme sürelerini al
    try:
        min_delay = int(input("En az bekleme süresi (dakika): ")) * 60  # Dakikayı saniyeye çevir
        max_delay = int(input("En fazla bekleme süresi (dakika): ")) * 60  # Dakikayı saniyeye çevir
        if min_delay > max_delay:
            print(f"{Fore.RED}❌ En az bekleme süresi, en fazla bekleme süresinden büyük olamaz.{Style.RESET_ALL}")
            return
    except ValueError:
        print(f"{Fore.RED}❌ Geçerli bir sayı girin.{Style.RESET_ALL}")
        return

    while True:
        try:
            loop_count = int(input("Döngü Sayısı: "))
            if loop_count <= 0:
                print("Lütfen 0'dan büyük bir sayı girin.")
                continue
        except ValueError:
            print("Geçerli bir sayı girin.")
            continue

        print(f"\n✅✅ Tüm komut dosyaları {loop_count} kez çalıştırılıyor...\n")
        
        for _ in range(loop_count):
            # aPriori Stake ve Unstake
            apriori_amount = get_random_amount(0.01, 0.05)
            stake_apriori_mon(apriori_amount)
            delay = get_random_delay(min_delay, max_delay)
            time.sleep(delay)  # Rastgele bekleme süresi
            unstake_apriori_mon(apriori_amount)
            delay = get_random_delay(min_delay, max_delay)
            time.sleep(delay)  # Rastgele bekleme süresi

            # Kitsu Stake ve Unstake
            kitsu_amount = get_random_amount(0.01, 0.05)
            stake_kitsu_mon(kitsu_amount)
            delay = get_random_delay(min_delay, max_delay)
            time.sleep(delay)  # Rastgele bekleme süresi
            unstake_kitsu_mon(kitsu_amount)
            delay = get_random_delay(min_delay, max_delay)
            time.sleep(delay)  # Rastgele bekleme süresi

            # Swap işlemleri (Uniswap, Bean, Bebop, Mono)
            for token_symbol, token_address in TOKEN_ADDRESSES.items():
                swap_eth_for_tokens(token_address, token_symbol)  # Uniswap
                delay = get_random_delay(min_delay, max_delay)
                time.sleep(delay)  # Rastgele bekleme süresi
                bean_swap_eth_for_tokens(token_address, token_symbol)  # Bean
                delay = get_random_delay(min_delay, max_delay)
                time.sleep(delay)  # Rastgele bekleme süresi
                bebop_swap_eth_for_tokens(token_address, token_symbol)  # Bebop
                delay = get_random_delay(min_delay, max_delay)
                time.sleep(delay)  # Rastgele bekleme süresi
                mono_swap_eth_for_tokens(token_address, token_symbol)  # Mono
                delay = get_random_delay(min_delay, max_delay)
                time.sleep(delay)  # Rastgele bekleme süresi

        print("\n✅✅ Tüm komut dosyaları başarıyla çalıştırıldı.\n")

if __name__ == "__main__":
    main()
