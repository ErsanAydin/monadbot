import os
import time
import random
from web3 import Web3
from dotenv import load_dotenv
from colorama import Fore, Style
from solcx import compile_source, install_solc

# .env dosyasından ortam değişkenlerini yükle
load_dotenv()

# RPC ve Cüzdan Ayarları
RPC_URL = "https://testnet-rpc.monad.xyz"
PRIVATE_KEY = os.getenv("PRIVATE_KEY")

# Web3 bağlantısı
web3 = Web3(Web3.HTTPProvider(RPC_URL))
if not web3.is_connected():
    raise Exception("RPC bağlantısı başarısız.")

# Solidity sürümünü yükle
install_solc('0.8.0')

# Kontrat Kaynak Kodu
contract_source_code = """
pragma solidity ^0.8.0;

contract Counter {
    uint256 private count;
    
    event CountIncremented(uint256 newCount);
    
    function increment() public {
        count += 1;
        emit CountIncremented(count);
    }
    
    function getCount() public view returns (uint256) {
        return count;
    }
}
"""

# Cüzdan Bakiyesini Kontrol Et
def check_balance(min_balance_eth):
    balance = web3.eth.get_balance(web3.eth.account.from_key(PRIVATE_KEY).address)
    balance_eth = web3.from_wei(balance, 'ether')
    if balance_eth < min_balance_eth:
        print(f"{Fore.RED}❌ Yetersiz bakiye: {balance_eth} ETH (Minimum gereken: {min_balance_eth} ETH){Style.RESET_ALL}")
        return False
    return True

# Kontratı Derle
def compile_contract():
    print(f"{Fore.BLUE}🪫 Kontrat Dağıtımı Başlatılıyor ⏩⏩⏩⏩{Style.RESET_ALL}")
    print(" ")

    compiled_sol = compile_source(contract_source_code, solc_version='0.8.0')
    contract_id, contract_interface = compiled_sol.popitem()
    bytecode = contract_interface['bin']
    abi = contract_interface['abi']

    print(f"{Fore.GREEN}✅ Kontrat başarıyla derlendi!{Style.RESET_ALL}")
    return abi, bytecode

# Gas Ücretlerini Otomatik Tahmin Etme
def get_dynamic_gas_fees():
    try:
        # Son blokların gas ücretlerini al
        fee_history = web3.eth.fee_history(1, 'latest', [10, 90])
        base_fee = fee_history['baseFeePerGas'][-1]
        max_priority_fee = web3.to_wei(2, 'gwei')  # Öncelik ücreti (2 Gwei)
        max_fee_per_gas = base_fee + max_priority_fee  # Maksimum gas ücreti

        return {
            'maxFeePerGas': max_fee_per_gas,
            'maxPriorityFeePerGas': max_priority_fee
        }
    except Exception as e:
        print(f"{Fore.RED}❌ Gas ücretleri tahmin edilirken hata: {e}{Style.RESET_ALL}")
        return {
            'maxFeePerGas': web3.to_wei(20, 'gwei'),  # Varsayılan değer
            'maxPriorityFeePerGas': web3.to_wei(2, 'gwei')  # Varsayılan değer
        }

# Kontratı Dağıt
async def deploy_contract(contract_name):
    abi, bytecode = compile_contract()
    print(f"{Fore.YELLOW}🚀 Kontrat dağıtılıyor: {contract_name}{Style.RESET_ALL}")

    # Cüzdan oluştur
    wallet = web3.eth.account.from_key(PRIVATE_KEY)
    nonce = web3.eth.get_transaction_count(wallet.address, 'pending')
    print(f"{Fore.LIGHTBLACK_EX}Nonce kullanılıyor: {nonce}{Style.RESET_ALL}")

    # Gas ücretlerini dinamik olarak al
    gas_fees = get_dynamic_gas_fees()

    # Kontratı dağıt
    contract = web3.eth.contract(abi=abi, bytecode=bytecode)
    tx = contract.constructor().build_transaction({
        'from': wallet.address,
        'nonce': nonce,
        'maxFeePerGas': gas_fees['maxFeePerGas'],
        'maxPriorityFeePerGas': gas_fees['maxPriorityFeePerGas'],
        'gas': 2000000,  # Gas limit
        'chainId': web3.eth.chain_id  # Zincir kimliği
    })

    # İşlemi imzala ve gönder
    signed_tx = wallet.sign_transaction(tx)
    try:
        tx_hash = web3.eth.send_raw_transaction(signed_tx.raw_transaction)  # Düzeltme: rawTransaction yerine raw_transaction
        print(f"{Fore.GREEN}✅ İşlem gönderildi! Onay bekleniyor...{Style.RESET_ALL}")
        
        # İşlemin onaylanmasını bekle
        tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)  # 120 saniye (2 dakika) timeout
        if tx_receipt.status == 1:
            print(f"{Fore.GREEN}✅ Kontrat başarıyla dağıtıldı!{Style.RESET_ALL}")
            print(f"{Fore.CYAN}📌 Kontrat Adresi: {Fore.YELLOW}{tx_receipt.contractAddress}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}📜 İşlem Hash: {Fore.YELLOW}{web3.to_hex(tx_hash)}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}✅ Dağıtım tamamlandı! 🎉{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}❌ İşlem başarısız!{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}❌ Dağıtım sırasında hata: {e}{Style.RESET_ALL}")

# Rastgele İsim Oluştur
def generate_random_name():
    chemical_terms = [
        "Atom", "Molecule", "Electron", "Proton", "Neutron", "Ion", "Isotope", "Reaction", "Catalyst", "Solution",
        "Acid", "Base", "pH", "Oxidation", "Reduction", "Bond", "Valence", "Electrolyte", "Polymer", "Monomer",
        "Enzyme", "Substrate", "Covalent", "Ionic", "Metal", "Nonmetal", "Gas", "Liquid", "Solid", "Plasma",
        "Entropy", "Enthalpy", "Thermodynamics", "OrganicChemistry", "InorganicChemistry", "Biochemistry", "PhysicalChemistry", "Analytical", "Synthesis", "Decomposition",
        "Exothermic", "Endothermic", "Stoichiometry", "Concentration", "Molarity", "Molality", "Titration", "Indicator", "Chromatography", "Spectroscopy",
        "Electrochemistry", "GalvanicCell", "Electrolysis", "Anode", "Cathode", "Electrode", "Hydrolysis", "Hydrogenation", "Dehydrogenation", "Polymerization",
        "Depolymerization", "Catalyst", "Inhibitor", "Adsorption", "Absorption", "Diffusion", "Osmosis", "Colloid", "Suspension", "Emulsion",
        "Aerosol", "Surfactant", "Detergent", "Soap", "AminoAcid", "Protein", "Carbohydrate", "Lipid", "Nucleotide", "DNA",
        "RNA", "ActivationEnergy", "Complex", "Ligand", "Coordination", "Crystal", "Amorphous", "Isomer", "Stereochemistry"
    ]

    planets = [
        "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "Ceres",
        "Eris", "Haumea", "Makemake", "Ganymede", "Titan", "Callisto", "Io", "Europa", "Triton", "Charon",
        "Titania", "Oberon", "Rhea", "Iapetus", "Dione", "Tethys", "Enceladus", "Miranda", "Ariel", "Umbriel",
        "Proteus", "Nereid", "Phobos", "Deimos", "Amalthea", "Himalia", "Elara", "Pasiphae", "Sinope", "Lysithea",
        "Carme", "Ananke", "Leda", "Thebe", "Adrastea", "Metis", "Callirrhoe", "Themisto", "Megaclite", "Taygete",
        "Chaldene", "Harpalyke", "Kalyke", "Iocaste", "Erinome", "Isonoe", "Praxidike", "Autonoe", "Thyone", "Hermippe",
        "Aitne", "Eurydome", "Euanthe", "Euporie", "Orthosie", "Sponde", "Kale", "Pasithee", "Hegemone", "Mneme",
        "Aoede", "Thelxinoe", "Arche", "Kallichore", "Helike", "Carpo", "Eukelade", "Cyllene", "Kore", "Herse",
        "Dia", "S2003J2", "S2003J3", "S2003J4", "S2003J5", "S2003J9", "S2003J10", "S2003J12", "S2003J15"
    ]

    combined_terms = chemical_terms + planets
    random.shuffle(combined_terms)
    return ''.join(combined_terms[:3])

# Ana İşlem
async def main():
    print(f"{Fore.BLUE}🪫 Kontrat Dağıtımı Başlatılıyor ⏩⏩⏩⏩{Style.RESET_ALL}")
    print(" ")

    # Cüzdan bakiyesini kontrol et (Minimum 0.01 ETH gerekiyor)
    if not check_balance(0.01):
        print(f"{Fore.RED}❌ Yetersiz bakiye. İşlemler durduruldu.{Style.RESET_ALL}")
        return

    number_of_contracts = 5
    for i in range(number_of_contracts):
        contract_name = generate_random_name()
        print(f"{Fore.YELLOW}🚀 {i + 1}/{number_of_contracts} kontrat dağıtılıyor: {contract_name}{Style.RESET_ALL}")
        await deploy_contract(contract_name)

        # Rastgele 3 ile 40 dakika arasında bekle
        delay = random.randint(180, 2400)  # 3 dakika = 180 saniye, 40 dakika = 2400 saniye
        print(f"{Fore.LIGHTBLACK_EX}⏳ {delay // 60} dakika {delay % 60} saniye bekleniyor...{Style.RESET_ALL}")
        time.sleep(delay)

    print(f"{Fore.GREEN}✅ Tüm kontratlar başarıyla dağıtıldı! 🎉{Style.RESET_ALL}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
